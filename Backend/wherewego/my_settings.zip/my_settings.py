DATABASES = {                                                                   
    'default': {                                                                
        'ENGINE': 'mysql.connector.django',
        # db 이름                                     
        'NAME': '',
        # db 관리자 계정명                                           
        'USER': '',
        # db 관리자 비밀번호                                                         
        'PASSWORD': '',                                              
        'HOST': '127.0.0.1',   # Or an IP Address that your DB is hosted on     
        'PORT': '3306',                                                         
        'TEST': {                                                               
            'CHARSET': 'utf8',                                                  
            'COLLATION': 'utf8_general_ci',                                     
        },                                                                      
        'OPTIONS': {                                                            
            'charset': 'utf8',                                                  
            'use_pure': True                                                    
        }                                                                       
    }                                                                           
}                                                                               
ALLOWED_HOSTS = [                                                               
    '*',                                                                        
]
